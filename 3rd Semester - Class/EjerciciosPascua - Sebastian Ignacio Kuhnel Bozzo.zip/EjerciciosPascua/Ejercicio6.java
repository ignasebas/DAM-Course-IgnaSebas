public class Ejercicio6 {
    public static void main(String args[]){
        int ancho = 25;
        int alto = 15;
        int perimetro = alto * 2 + ancho * 2;
        int area = ancho * alto;
        System.out.println("El rectangulo tiene dos lados de " + ancho + "cm y otros dos lados de " + alto + "cm.");
        System.out.println("El perimetro del rectangulo es de " + perimetro + "cm.");
        System.out.println("El area del rectangulo es de " + area + "cm cuadrados.");
    }
}
